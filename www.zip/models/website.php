<?php
class Website extends AppModel {
	var $name = 'Website';
}
?>