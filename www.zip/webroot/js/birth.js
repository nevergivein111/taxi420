// JavaScript Document
window.onload=init;

function init()
{
	document.getElementById("months").onchange=change;
	
	}
	
	function change()
{
	var monthDays =new Array(31,28,31,30,31,30,31,31,30,31,30,31);
	var x= document.getElementById("months").selectedIndex;
	var monthStr = document.getElementById("months").options[x].value;
	
	if(monthStr != "") {
	document.getElementById("days").options.length=0;
	
	for(var i=0; i<monthDays[monthStr];i++)
	{
		document.getElementById("days").options[i]=new Option(i+1);

		
		}
	
	}
	

		}