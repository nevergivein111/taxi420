// Hover State Animations
$(document).ready(function(){
	// Sign in panel toggle
	$("#signin_show").click(function(){
		$("#signin_panel").slideToggle({duration: 800, easing: 'easeOutSine'});
	},
	function(){
		$(this).find("span").stop().animate({right:'-70px'},{ queue: false, duration: 150, easing: 'easeInBack'});
	});
	// Video thumbnails Watch Now effect
	$('.video_thumbnail').hover(function(){
		$(this).find("span").stop().animate({right:'0px'},{ queue: false, duration: 300, easing: 'easeOutSine'});
	},
	function(){
		$(this).find("span").stop().animate({right:'-70px'},{ queue: false, duration: 150, easing: 'easeInBack'});
	});
	// Thumbnail pictures in Browse album pages
	$('.pictures_entry a').hover(function(){
		$(this).find("img").stop().animate({opacity:'0.25'},{ queue: false, duration: 600, easing: 'easeOutSine'});
	},
	function(){
		$(this).find("img").stop().animate({opacity:'1'},{ queue: false, duration: 400, easing: 'easeOutSine'});
	});
 });


// Menu navigation Dropmenu
$(document).ready(function(){
	$('.sub_menu').css("display","none");
	// Find and add class to the Li parent of Ul sub_menu
	$(".sub_menu").parent('li').addClass("drop");
	$(".drop").hover(function(){
			$(this).find('.sub_menu').slideDown(100);
	},function(){
			$(this).find('.sub_menu').slideUp(100);
	});
		$(".sub_menu a").hover(function(){
		$(this).find('span').stop().animate({marginLeft:'10px'},{queue:false, duration:125, easing: 'easeInCubic'})
	},function(){
		$(this).find('span').stop().animate({marginLeft:'0px'},{queue:false, duration:250, easing: 'easeOutSine'})
	});
 });


// Animate the lists...
$(document).ready(function(){
		$("#sidebar li a").wrapInner("<span></span>");
		$("#sidebar li a").hover(function(){
		$(this).find('span').stop().animate({marginLeft:'10px'},{queue:false, duration:125, easing: 'easeInCubic'})
	},function(){
		$(this).find('span').stop().animate({marginLeft:'0px'},{queue:false, duration:250, easing: 'easeOutSine'})
	});
});

// Share network
$(document).ready(function(){
	// Display the sharing menu
	$('.sharing ul').css("opacity", "0");
	$('.sharing').hover(function(){
	$('.sharing ul').css("display","block");
		$(this).find("ul").stop().animate({opacity:'1'},{ queue: false, duration: 300});
	},
	function(){
		$(this).find("ul").stop().animate({opacity:'0'},{ queue: false, duration: 90});
		$('.sharing ul').delay(300).css("display","none");
	});
	// Display the names of the networks
	$('.sharing ul span').css("opacity", "0");
	$('.sharing li').hover(function(){
		$(this).find("span").stop().animate({opacity:'1'},{ queue: false, duration: 150});
	},
	function(){
		$(this).find("span").stop().animate({opacity:'0'},{ queue: false, duration: 150});
	});
 });



// Captcha system
$(document).ready(function(){

			$("#errorcaptcha").css({opacity: "0"});
$("#check").keyup(function () {
		var rep = $(this).val();
		var n1 = document.getElementById('num1').innerHTML;
		var n2 = document.getElementById('num2').innerHTML;
		var n3 = parseInt(n1) + parseInt(n2);
      		if( n3 == rep ){
			$("#submitter").prepend('<input type="submit" name="contact_submit" id="contact_submit" value="Submit" class="cufon" />').animate({opacity: "1"},{duration:350});
			$("#errorcaptcha").text(" ").animate({opacity: "0"},{duration:150});
		}
		else {
			$("#errorcaptcha").text("Not good!").animate({opacity: "1"},{duration:350});
			$("#submitter").prepend('').animate({opacity: "0"},{duration:150}).empty();
		}
    });

 });