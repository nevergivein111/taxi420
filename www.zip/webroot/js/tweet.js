// TWITTER DISPLAY
$(document).ready(function(){
	getTwitters('deadTweets', {
		id: document.getElementById('tweeter').innerHTML, 
		prefix: '',  // If you want display your avatar and name <img height="16" width="16" src="%profile_image_url%" /><a href="http://twitter.com/%screen_name%">%name%</a> said:<br/>
		clearContents: false, // leave the original message in place
		count: 1, 
		withFriends: true,
		ignoreReplies: false,
		newwindow: true
	});
});
	

function twitterCounter(twitters) {
var usercount = twitters[0].user.followers_count
document.getElementById('twitter_counter').innerHTML = usercount;
}