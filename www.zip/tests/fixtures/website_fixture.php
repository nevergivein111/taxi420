<?php
/* Website Fixture generated on: 2011-05-23 09:30:58 : 1306143058 */
class WebsiteFixture extends CakeTestFixture {
	var $name = 'Website';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'key' => 'primary'),
		'aboutus' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 300, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

	var $records = array(
		array(
			'id' => 1,
			'aboutus' => 'Lorem ipsum dolor sit amet'
		),
	);
}
?>