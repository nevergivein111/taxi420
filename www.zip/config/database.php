<?php
class DATABASE_CONFIG {

	var $default = array(
		'driver' => 'mysql',
		'persistent' => false,
		'host' => 'MYSQLHOST',
		'login' => 'u70846484',
		'password' => '42e235',
		'database' => 'd60776098',
	);
}
?>